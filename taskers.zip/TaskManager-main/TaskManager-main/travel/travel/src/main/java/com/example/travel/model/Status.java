package com.example.travel.model;

public enum Status {
	 Pending,
	 In_Progress,
	 Completed
}